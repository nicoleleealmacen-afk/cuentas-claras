# Cuentas Claras 2.0 — Android

Aplicación financiera personal offline. Esta versión agrega calendario de pagos, pagos recurrentes, prioridades y cálculo automático de apartados semanales.

## Funciones
- Ingreso semanal y disponible real.
- Gastos recurrentes y equivalencia semanal.
- Deudas y pagos.
- Metas de ahorro.
- Calendario mensual de pagos.
- Pagos programados: una vez, semanal, cada 2 semanas, mensual, cada 3 meses y anual.
- Prioridades: obligatorio, importante y normal.
- El pago programado se toma en cuenta en el balance mediante un apartado semanal equivalente.
- Próximos pagos, vencidos y pagos cercanos.
- Planificador de 6 semanas.
- Historial y respaldos JSON.
- Funcionamiento local/offline.

## Compilación
Abrir el proyecto en Android Studio y ejecutar `Build > Build APK(s)`.
