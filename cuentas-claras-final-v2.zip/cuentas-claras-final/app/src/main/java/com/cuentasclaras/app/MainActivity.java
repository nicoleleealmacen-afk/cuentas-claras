package com.cuentasclaras.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.content.Intent;
import android.net.Uri;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
  private WebView web;
  @Override public void onCreate(Bundle state){
    super.onCreate(state);
    web=new WebView(this);
    web.setWebViewClient(new WebViewClient());
    WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true); s.setAllowContentAccess(true);
    web.addJavascriptInterface(new NativeBridge(), "Android");
    web.loadUrl("file:///android_asset/www/index.html"); setContentView(web);
  }
  @Override public void onBackPressed(){ if(web.canGoBack()) web.goBack(); else super.onBackPressed(); }
  public class NativeBridge {
    @JavascriptInterface public void shareBackup(String json){
      Intent i=new Intent(Intent.ACTION_SEND); i.setType("application/json"); i.putExtra(Intent.EXTRA_TEXT,json); startActivity(Intent.createChooser(i,"Compartir respaldo"));
    }
  }
}
